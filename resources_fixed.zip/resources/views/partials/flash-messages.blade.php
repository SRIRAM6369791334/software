@if(session('success'))
    <div x-data="{ show: true }" x-show="show" x-transition:leave="transition ease-in duration-300" x-transition:leave-start="opacity-100 translate-y-0" x-transition:leave-end="opacity-0 -translate-y-2"
         class="mb-5 flex items-center justify-between gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-800 shadow-sm">
        <div class="flex items-center gap-3">
            <span class="material-symbols-rounded text-xl text-emerald-600">check_circle</span>
            {{ session('success') }}
        </div>
        <button onclick="this.closest('[x-data]') ? null : this.parentElement.remove()" onclick="this.parentElement.remove()" class="rounded-lg p-1 text-emerald-500 hover:bg-emerald-100 transition-colors">
            <span class="material-symbols-rounded text-base">close</span>
        </button>
    </div>
@endif

@if(session('error'))
    <div class="mb-5 flex items-center justify-between gap-3 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-800 shadow-sm">
        <div class="flex items-center gap-3">
            <span class="material-symbols-rounded text-xl text-red-500">error</span>
            {{ session('error') }}
        </div>
        <button onclick="this.parentElement.remove()" class="rounded-lg p-1 text-red-400 hover:bg-red-100 transition-colors">
            <span class="material-symbols-rounded text-base">close</span>
        </button>
    </div>
@endif

@if(session('warning'))
    <div class="mb-5 flex items-center justify-between gap-3 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-800 shadow-sm">
        <div class="flex items-center gap-3">
            <span class="material-symbols-rounded text-xl text-amber-500">warning</span>
            {{ session('warning') }}
        </div>
        <button onclick="this.parentElement.remove()" class="rounded-lg p-1 text-amber-400 hover:bg-amber-100 transition-colors">
            <span class="material-symbols-rounded text-base">close</span>
        </button>
    </div>
@endif

@if($errors->any())
    <div class="mb-5 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800 shadow-sm">
        <p class="mb-1 flex items-center gap-2 font-bold">
            <span class="material-symbols-rounded text-xl text-red-500">report_problem</span>
            Please fix the following errors:
        </p>
        <ul class="ml-7 list-disc space-y-0.5">
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
