@extends('layouts.app')
@section('title', 'Customer Details')

@section('content')
<div class="mb-6 flex justify-between items-end">
    <div>
        <a href="{{ route('masters.customers.index') }}" class="text-xs font-semibold text-emerald-600 hover:text-emerald-700 uppercase tracking-wider mb-2 inline-block">← Back to Customers</a>
        <h1 class="text-2xl font-bold text-slate-950">{{ $customer->name }}</h1>
        <p class="text-sm text-slate-500 mt-0.5">{{ $customer->type }} Customer | {{ $customer->route ?? 'No route assigned' }}</p>
    </div>
    <div class="flex gap-2">
        <a href="{{ route('masters.customers.edit', $customer) }}" class="px-4 py-2 bg-gradient-to-br from-white via-emerald-50/30 to-sky-50/30 border border-slate-200 rounded-lg text-sm font-bold text-slate-700 hover:bg-emerald-50 shadow-sm transition-all">Edit Details</a>
        <form action="{{ route('masters.customers.destroy', $customer) }}" method="POST" onsubmit="return confirm('Delete this customer? This action is permanent.')">
            @csrf @method('DELETE')
            <button type="submit" class="px-4 py-2 bg-red-50 text-red-600 border border-red-100 rounded-lg text-sm font-bold hover:bg-red-100 transition-all">Delete</button>
        </form>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    {{-- Info Card --}}
    <div class="space-y-6">
        <div class="bg-gradient-to-br from-white via-emerald-50/40 to-sky-50/40 rounded-xl border border-slate-200 shadow-sm overflow-hidden p-6 space-y-4">
            <h3 class="text-xs font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2">Profile Information</h3>
            <div class="space-y-3">
                <div>
                    <p class="text-[10px] font-bold text-slate-400 uppercase">Contact Phone</p>
                    <p class="text-sm font-semibold text-slate-950">{{ $customer->phone }}</p>
                </div>
                <div>
                    <p class="text-[10px] font-bold text-slate-400 uppercase">Addresses</p>
                    <p class="text-sm text-slate-700 break-words">{{ $customer->address ?: 'Not provided' }}</p>
                </div>
                <div>
                    <p class="text-[10px] font-bold text-slate-400 uppercase">GST Number</p>
                    <p class="text-sm font-mono text-slate-950">{{ $customer->gst_number ?: 'Unregistered' }}</p>
                </div>
            </div>
        </div>

        <div class="bg-emerald-600 rounded-xl shadow-lg p-6 text-white text-center">
            <p class="text-[10px] font-bold uppercase tracking-widest opacity-80 mb-1">Total Outstanding</p>
            <h2 class="text-3xl font-black">Rs {{ number_format($customer->balance, 2) }}</h2>
            <div class="mt-6 pt-6 border-t border-white/10 flex flex-col gap-3">
                <a href="{{ route('payments.customers.create', ['customer_id' => $customer->id]) }}" 
                   class="w-full text-center px-6 py-3 bg-white text-emerald-700 text-[10px] font-black uppercase tracking-[0.2em] rounded-xl shadow-lg hover:shadow-md transition-all active:scale-95">
                   Record Payment 
                </a>
                <a href="{{ route('masters.customers.ledger-pdf', $customer) }}" 
                   class="w-full text-center px-6 py-3 bg-emerald-700 text-white text-[10px] font-black uppercase tracking-[0.2em] rounded-xl shadow-lg hover:bg-emerald-800 transition-all active:scale-95">
                   Download Statement 
                </a>
            </div>
        </div>
    </div>

    {{-- Activity Tabs --}}
    <div class="lg:col-span-2 space-y-6">
        <div class="bg-gradient-to-br from-white via-emerald-50/40 to-sky-50/40 rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div class="flex border-b border-slate-200">
                <a href="{{ route('masters.customers.show', $customer) }}" class="px-6 py-4 text-sm font-bold text-emerald-600 border-b-2 border-emerald-600">Quick Overview</a>
                <a href="{{ route('masters.customers.billing-history', $customer) }}" class="px-6 py-4 text-sm font-semibold text-slate-500 hover:text-slate-950">Billing History</a>
                <a href="{{ route('masters.customers.payment-history', $customer) }}" class="px-6 py-4 text-sm font-semibold text-slate-500 hover:text-slate-950">Payment History</a>
            </div>
            
            <div class="p-6">
                <h4 class="text-sm font-bold text-slate-950 mb-4 uppercase tracking-tight">Recent Activity Insights</h4>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="p-4 bg-emerald-50 rounded-xl border border-slate-200">
                        <p class="text-[10px] font-bold text-slate-400 uppercase mb-1">Last Bill Date</p>
                        <p class="text-sm font-bold text-slate-950">{{ $latestBill?->period_end->format('d M Y') ?? 'No bills yet' }}</p>
                    </div>
                    <div class="p-4 bg-emerald-50 rounded-xl border border-slate-200">
                        <p class="text-[10px] font-bold text-slate-400 uppercase mb-1">Last Payment</p>
                        <p class="text-sm font-bold text-slate-950">Rs {{ number_format($latestPayment?->amount ?? 0, 0) }} ({{ $latestPayment?->date->format('d M') ?? 'N/A' }})</p>
                    </div>
                </div>
                <div class="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div class="p-4 bg-emerald-50 rounded-xl border border-emerald-100 text-center">
                        <p class="text-[10px] font-bold text-emerald-600 uppercase mb-1">Total Bills Generated</p>
                        <p class="text-xl font-black text-emerald-700">{{ $customer->weekly_bills_count }}</p>
                    </div>
                    <div class="p-4 bg-blue-50 rounded-xl border border-blue-100 text-center">
                        <p class="text-[10px] font-bold text-blue-600 uppercase mb-1">Total Payments Made</p>
                        <p class="text-xl font-black text-blue-700">{{ $customer->payments_count }}</p>
                    </div>
                    <div class="p-4 bg-purple-50 rounded-xl border border-purple-100 text-center">
                        <p class="text-[10px] font-bold text-purple-600 uppercase mb-1">Total Paid Amount</p>
                        <p class="text-xl font-black text-purple-700">Rs {{ number_format($customer->payments_sum_amount ?? 0, 0) }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
