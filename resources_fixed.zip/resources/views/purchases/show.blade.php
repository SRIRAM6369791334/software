@extends('layouts.app')
@section('title', 'Purchase Invoice #' . $purchase->id)

@section('content')
<div class="mb-6 flex justify-between items-end">
    <div>
        <a href="{{ route('purchases.entry') }}" class="text-xs font-semibold text-emerald-600 hover:text-emerald-700 uppercase tracking-wider mb-2 inline-block">← Back to Purchases</a>
        <h1 class="text-2xl font-bold text-slate-950">Purchase Invoice</h1>
        <p class="text-sm text-slate-500 mt-0.5">Reference: #PUR{{ str_pad($purchase->id, 5, '0', STR_PAD_LEFT) }}</p>
    </div>
    <div class="flex gap-2">
        <a href="{{ route('purchases.print', $purchase->id) }}" class="px-4 py-2 bg-gradient-to-br from-white via-emerald-50/30 to-sky-50/30 border border-slate-200 text-white rounded-lg text-sm font-bold hover:bg-emerald-50 shadow-sm transition-all">Print </a>
        <a href="{{ route('purchases.edit', $purchase->id) }}" class="px-4 py-2 bg-gradient-to-br from-white via-emerald-50/30 to-sky-50/30 border border-slate-200 rounded-lg text-sm font-bold text-slate-700 hover:bg-emerald-50 shadow-sm transition-all">Edit</a>
    </div>
</div>

<div class="max-w-4xl">
    <div class="bg-gradient-to-br from-white via-emerald-50/40 to-sky-50/40 rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-8">
        <div class="flex justify-between items-start mb-10 pb-8 border-b border-slate-200">
            <div class="space-y-4">
                <div>
                    <h3 class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Supplier</h3>
                    <h2 class="text-xl font-black text-slate-950">{{ $purchase->vendor_name }}</h2>
                </div>
                <div class="text-xs text-slate-500 space-y-1">
                    <p>Contact Info from Master Record</p>
                    <p class="italic">Recorded via Purchase Entry</p>
                </div>
            </div>
            <div class="text-right space-y-4">
                <div>
                    <h3 class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Billing Date</h3>
                    <p class="text font-bold text-slate-950">{{ $purchase->date->format('d F, Y') }}</p>
                </div>
                <div>
                    <h3 class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Payment Mode</h3>
                    <span class="px-2 py-1 bg-emerald-50 text-emerald-700 text-[10px] font-black uppercase rounded">{{ $purchase->payment_mode }}</span>
                </div>
            </div>
        </div>

        <table class="w-full text-sm mb-10">
            <thead>
                <tr class="text-left text-xs font-bold text-slate-400 uppercase border-b border-slate-200">
                    <th class="pb-3">Item Description</th>
                    <th class="pb-3 text-right">Qty</th>
                    <th class="pb-3 text-right">Rate</th>
                    <th class="pb-3 text-right">Amount</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                @php $subtotal = 0; @endphp
                @foreach($purchase->items as $item)
                @php 
                    $rowTotal = $item->quantity * $item->rate;
                    $subtotal += $rowTotal;
                @endphp
                <tr class="text-slate-950">
                    <td class="py-6">
                        <p class="font-bold border-l-4 border-emerald-500 pl-3">{{ $item->item_name }}</p>
                        <p class="text-xs text-slate-400 pl-3">Standard stock procurement</p>
                    </td>
                    <td class="py-6 text-right font-mono">{{ number_format($item->quantity, 2) }} {{ $item->unit }}</td>
                    <td class="py-6 text-right">Rs {{ number_format($item->rate, 2) }}</td>
                    <td class="py-6 text-right font-bold">Rs {{ number_format($rowTotal, 2) }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>

        <div class="flex justify-end">
            <div class="w-full md:w-64 space-y-3">
                <div class="flex justify-between text-sm text-slate-500">
                    <span>Subtotal</span>
                    <span>Rs {{ number_format($subtotal, 2) }}</span>
                </div>
                <div class="flex justify-between text-sm text-slate-500">
                    <span>GST ({{ $purchase->gst_percentage }}%)</span>
                    <span>Rs {{ number_format($purchase->gst_amount, 2) }}</span>
                </div>
                <div class="flex justify-between pt-3 border-t-2 border-gray-900 text-lg font-black text-slate-950">
                    <span>Total Amount</span>
                    <span>Rs {{ number_format($purchase->total_amount, 2) }}</span>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
